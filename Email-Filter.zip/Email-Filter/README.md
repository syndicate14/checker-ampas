# Email-Filter

How To Use This Tools ?

```
$. git clone https://github.com/alchadecode/Email-Filter
$. cd Email-Filter
$. chmod +x filter.sh
$. ./filter.sh
```

>AlchaDecode 2K18
