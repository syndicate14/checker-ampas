# Sbuxcard-Fetch-Login
![Image Of RunFile](https://image.ibb.co/jMLr6d/alchaprosbux.png)

How To Use This Tools ?

```
$. git clone https://github.com/alchadecode/Sbuxcard-Fetch-Login
$. cd Sbuxcard-Fetch-Login
$. chmod +x sbux.sh
$. ./sbux.sh
```
Lo Jual / Lo Ubah Nama / Copyright Gue? LO MATI!

>AlchaDecode 2K18
