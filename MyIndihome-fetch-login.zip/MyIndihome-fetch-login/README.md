# MyIndihome-fetch-login
![Image Of RunFile](https://image.ibb.co/hxLKQJ/Screenshot_72.png)


How To Use This Tools ?

```
$. git clone https://github.com/alchadecode/MyIndihome-fetch-login
$. cd MyIndihome-fetch-login
$. chmod +x MyIndihome.sh
$. ./MyIndihome.sh
```

>AlchaDecode 2K18
